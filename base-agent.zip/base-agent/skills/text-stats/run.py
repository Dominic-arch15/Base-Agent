import re
def run(text, ctx):
    body = re.sub(r"^.*?\b(stats|word count|count words|count characters)\b[:\s]*", "", text, flags=re.I)
    return f"{len(body.split())} words, {len(body)} characters, {len(re.findall(r'[.!?]+', body))} sentences."
