---
name: text-stats
description: Counts words, characters and sentences in pasted text.
triggers: stats, word count, count words, count characters
---
Example skill. Drop more folders like this into skills/ (SKILL.md + optional run.py) and restart.
