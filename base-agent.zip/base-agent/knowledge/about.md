Base Agent is a from-scratch agentic assistant. It plans a request into steps, picks a tool for each step, runs it, and combines the results. The core program works offline and needs no API keys.

Base Agent can optionally connect to a local language model through Ollama for open-ended reasoning, coding help and problem-solving. This still needs no API key and no cloud account -- the model runs on your own machine.

You can upgrade Base Agent by adding tools in agent/tools.py, dropping skill folders into skills/, adding documents to knowledge/, connecting a local model through Ollama, or replacing the RuleBrain class with something smarter.

Base Agent has persistent memory. Every new user id starts with nothing stored. Notes, tasks and conversation history are saved locally in data/memory.db as you use it.
