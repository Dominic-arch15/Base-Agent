"""Web server (standard library only). Run: python server.py  ->  http://localhost:8000
Reads config.json in this folder (brain mode, Ollama settings, feature toggles)."""
import json, os
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from agent.core import Agent

agent = Agent()
WEB = os.path.join(os.path.dirname(__file__), "web")

class H(BaseHTTPRequestHandler):
    def _send(self, code, body, ctype="application/json"):
        b = body if isinstance(body, bytes) else json.dumps(body).encode()
        self.send_response(code); self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(b))); self.end_headers(); self.wfile.write(b)

    def do_GET(self):
        if self.path == "/api/tools":
            return self._send(200, {k: v["doc"] for k, v in agent.registry.items()})
        if self.path == "/api/config":
            return self._send(200, agent.config)
        if self.path == "/api/health":
            return self._send(200, {"ok": True, "brain": "ollama" if agent.current_brain() is agent.ollama else "rule"})
        if self.path in ("/", "/index.html"):
            return self._send(200, open(os.path.join(WEB, "index.html"), "rb").read(), "text/html; charset=utf-8")
        self._send(404, {"error": "not found"})

    def do_POST(self):
        if self.path == "/api/chat":
            try:
                n = min(int(self.headers.get("Content-Length", 0)), 20000)
                d = json.loads(self.rfile.read(n))
                return self._send(200, agent.run(str(d.get("session", "anon")), str(d.get("message", ""))))
            except Exception as e:
                return self._send(400, {"error": str(e)})
        self._send(404, {"error": "not found"})

    def log_message(self, *a): pass

if __name__ == "__main__":
    host, port = os.environ.get("HOST", "0.0.0.0"), int(os.environ.get("PORT", 8000))
    print(f"Base Agent running at http://localhost:{port}  (brain: {agent.config.get('brain', 'auto')})")
    ThreadingHTTPServer((host, port), H).serve_forever()
