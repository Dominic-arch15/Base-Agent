"""Optional DESKTOP voice loop. The web UI (web/index.html) already has its own
browser-based microphone/speaker support and needs none of this.

Use this instead if you want a standalone, non-browser voice assistant on this machine.
Needs extra packages the core agent does not: pip install pyttsx3 SpeechRecognition pyaudio
(PyAudio is the fiddly one on Windows -- see README for notes.)

Run directly:  python -m agent.voice
"""
import os, sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

def speak(text):
    try:
        import pyttsx3
        engine = pyttsx3.init()
        engine.say(text)
        engine.runAndWait()
    except Exception as e:
        print(f"[voice] couldn't use the speaker ({e}); printing instead:\n{text}")

def listen():
    import speech_recognition as sr
    r = sr.Recognizer()
    with sr.Microphone() as source:
        print("Listening...")
        audio = r.listen(source, phrase_time_limit=12)
    try:
        # Free and keyless, but sends the audio clip to Google for transcription.
        # Swap this line for a Vosk model if you want speech-to-text fully offline too.
        return r.recognize_google(audio)
    except Exception as e:
        print(f"[voice] didn't catch that ({e})")
        return ""

if __name__ == "__main__":
    from agent.core import Agent
    agent = Agent()
    print("Voice mode. Speak after 'Listening...'. Ctrl+C to quit.")
    while True:
        try:
            heard = listen()
            if not heard:
                continue
            print("You:", heard)
            result = agent.run("voice", heard)
            print("Agent:", result["reply"])
            speak(result["reply"])
        except KeyboardInterrupt:
            print("\nBye.")
            break
