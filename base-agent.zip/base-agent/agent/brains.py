"""Pluggable reasoning backends. Both expose respond(text, ctx, registry, history) -> (reply, trace).

RuleBrain   -- offline keyword router. Always available, nothing to install, limited to the
               built-in tools: it cannot answer open-ended questions a tool doesn't cover.
OllamaBrain -- real reasoning, coding and problem-solving via a model YOU run locally with
               Ollama (https://ollama.com). No cloud account, no API key, nothing sent off
               your machine. Install Ollama, run `ollama pull llama3.1` (or any model you
               like) once, then it works with no internet at all.
"""
import json, re, urllib.request

class RuleBrain:
    def decide(self, text, registry):
        t = text.lower()
        words = set(re.findall(r"[a-z0-9']+", t))
        best, top = None, 0
        for name, tl in registry.items():
            s = sum(2 for k in tl["keywords"] if " " in k and k in t) + len(words & set(tl["keywords"])) * 2
            if name == "calculator" and re.search(r"\d\s*[-+*/^]\s*\d", t):
                s += 4
            if s > top:
                best, top = name, s
        return best

    def plan(self, text, registry):
        steps = [s.strip() for s in re.split(r";|\bthen\b|\balso\b", text, flags=re.I) if s.strip()]
        out = []
        for s in steps:
            sub = [c.strip() for c in re.split(r"\s+and\s+", s, flags=re.I) if c.strip()]
            ok = len(sub) > 1 and all(self.decide(c, registry) for c in sub)
            out += sub if ok else [s]
        return out or [text]

    def respond(self, text, ctx, registry, history):
        trace, replies = [], []
        for step in self.plan(text, registry):
            name = self.decide(step, registry)
            try:
                res = registry[name]["fn"](step, ctx) if name else (
                    "I can't do that in offline mode. Say 'help' for my abilities, "
                    "or set up Ollama (see README) for open-ended reasoning.")
            except Exception as e:
                res = f"That tool failed: {e}"
            trace.append({"step": step, "tool": name or "none", "result": str(res)[:200]})
            replies.append(str(res))
        return "\n\n".join(replies), trace


class OllamaBrain:
    def __init__(self, url="http://localhost:11434", model="llama3.1", rule_brain=None):
        self.url, self.model, self.rules = url.rstrip("/"), model, rule_brain or RuleBrain()

    def available(self):
        try:
            urllib.request.urlopen(self.url + "/api/tags", timeout=2)
            return True
        except Exception:
            return False

    def _chat(self, messages):
        body = json.dumps({"model": self.model, "messages": messages, "stream": False}).encode()
        req = urllib.request.Request(self.url + "/api/chat", data=body, headers={"Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=120) as r:
            return json.loads(r.read())["message"]["content"]

    def respond(self, text, ctx, registry, history):
        tool_list = "\n".join(f"- {n}: {t['doc']}" for n, t in registry.items())
        sys_prompt = (
            "You are a capable local assistant with access to tools that run on the user's own machine. "
            "To use one, reply on a single line with exactly: TOOL: <tool_name>: <input for the tool> "
            "and nothing else on that line. Otherwise just answer normally, using your own knowledge for "
            "reasoning, coding, and problem-solving.\n\nAvailable tools:\n" + tool_list)
        messages = [{"role": "system", "content": sys_prompt}] + history + [{"role": "user", "content": text}]
        trace = []
        for _ in range(3):
            try:
                reply = self._chat(messages)
            except Exception as e:
                rule_reply, rule_trace = self.rules.respond(text, ctx, registry, history)
                return rule_reply + f"\n\n(Local model unreachable, used offline mode instead: {e})", rule_trace
            m = re.match(r"\s*TOOL:\s*([\w_]+)\s*:\s*(.*)", reply, re.S)
            if not m:
                return reply.strip(), trace
            name, arg = m.group(1).strip(), m.group(2).strip()
            if name not in registry:
                messages += [{"role": "assistant", "content": reply},
                             {"role": "user", "content": f"There's no tool called {name}. Pick from the list or answer directly."}]
                continue
            try:
                result = registry[name]["fn"](arg, ctx)
            except Exception as e:
                result = f"error: {e}"
            trace.append({"step": text, "tool": name, "result": str(result)[:200]})
            messages += [{"role": "assistant", "content": reply},
                         {"role": "user", "content": f"Tool result: {result}\n\nNow answer the original request."}]
        return "I made several tool calls but couldn't finish -- try rephrasing.", trace
