"""Built-in tools. Add your own with @tool(keywords...) -- the agent picks them up automatically.
Every tool receives (text, ctx). ctx has: mem (Memory), sid (user id), agent, scheduler, config."""
import ast, datetime, glob, operator as op, os, platform, re, socket, subprocess, sys, tempfile, urllib.request
REGISTRY = {}
ROOT = os.path.join(os.path.dirname(__file__), "..")

def tool(*keywords):
    def deco(fn):
        REGISTRY[fn.__name__] = {"fn": fn, "keywords": list(keywords), "doc": (fn.__doc__ or "").strip()}
        return fn
    return deco

# ---------- calculator ----------
OPS = {ast.Add: op.add, ast.Sub: op.sub, ast.Mult: op.mul, ast.Div: op.truediv,
       ast.Pow: op.pow, ast.Mod: op.mod, ast.FloorDiv: op.floordiv, ast.USub: op.neg}

def _ev(n):
    if isinstance(n, ast.Constant) and isinstance(n.value, (int, float)): return n.value
    if isinstance(n, ast.UnaryOp) and type(n.op) in OPS: return OPS[type(n.op)](_ev(n.operand))
    if isinstance(n, ast.BinOp) and type(n.op) in OPS:
        a, b = _ev(n.left), _ev(n.right)
        if isinstance(n.op, ast.Pow) and abs(b) > 100: raise ValueError("exponent too large")
        return OPS[type(n.op)](a, b)
    raise ValueError("unsupported expression")

@tool("calculate", "calc", "compute", "plus", "minus", "times", "divided", "math")
def calculator(text, ctx):
    """Calculate arithmetic, e.g. 'calculate (12+8)*3'."""
    parts = re.findall(r"[\d+\-*/().%\s]+", text.replace("^", "**").replace("×", "*"))
    expr = max(parts, key=len).strip() if parts else ""
    if not expr: return "Give me an expression, e.g. 12*(3+4)."
    return f"{expr} = {round(_ev(ast.parse(expr, mode='eval').body), 10)}"

@tool("time", "date", "today", "day", "now")
def clock(text, ctx):
    """Tell the current date and time."""
    return datetime.datetime.now().strftime("It is %A, %d %B %Y, %H:%M.")

# ---------- memory-backed notes / todos ----------
@tool("note", "notes", "remember")
def notes(text, ctx):
    """Save or list notes: 'note buy milk' / 'show my notes'."""
    L = ctx["mem"].get(ctx["sid"], "notes", [])
    if re.search(r"\b(list|show|read|what)\b", text, re.I) and "notes" in text.lower():
        return "\n".join(f"{i+1}. {n}" for i, n in enumerate(L)) or "No notes yet."
    body = re.sub(r"^.*?\b(note|remember)\b( that| this)?[:\s]*", "", text, flags=re.I).strip()
    if not body: return "Tell me what to note, e.g. 'note buy milk'."
    L.append(body); ctx["mem"].set(ctx["sid"], "notes", L); return f"Saved note: {body}"

@tool("todo", "task", "tasks")
def todos(text, ctx):
    """Manage tasks: 'add task call Ravi' / 'show tasks' / 'done task 1'."""
    L = ctx["mem"].get(ctx["sid"], "todos", [])
    m = re.search(r"\b(?:done|complete|finish)\s+(?:task\s+)?#?(\d+)", text, re.I)
    if m:
        i = int(m.group(1)) - 1
        if 0 <= i < len(L):
            L[i]["done"] = True; ctx["mem"].set(ctx["sid"], "todos", L); return f"Completed: {L[i]['text']}"
        return "No task with that number."
    if re.search(r"\b(list|show|what)\b", text, re.I):
        return "\n".join(f"{i+1}. [{'x' if t['done'] else ' '}] {t['text']}" for i, t in enumerate(L)) or "No tasks yet."
    body = re.sub(r"^.*?\b(?:todo|tasks?)\b( to)?[:\s]*", "", text, flags=re.I).strip()
    if not body: return "Tell me the task, e.g. 'add task send report'."
    L.append({"text": body, "done": False}); ctx["mem"].set(ctx["sid"], "todos", L); return f"Added task {len(L)}: {body}"

# ---------- knowledge + summarizing ----------
STOP = set("the a an is are was of to in on and or for it this that what who how why tell me about explain do you can i".split())
def _words(s): return [w for w in re.findall(r"[a-z0-9]+", s.lower()) if w not in STOP]

@tool("search", "find", "what", "who", "how", "why", "explain", "tell", "about", "know")
def search_knowledge(text, ctx):
    """Answer from the local knowledge/ folder (.md/.txt files)."""
    q, best, score = set(_words(text)), None, 0
    for f in glob.glob(os.path.join(ROOT, "knowledge", "*")):
        for para in open(f, encoding="utf-8").read().split("\n\n"):
            s = len(q & set(_words(para)))
            if s > score: best, score = para.strip(), s
    return best if best else "I found nothing about that in my knowledge folder."

@tool("summarize", "summary", "summarise", "tldr", "shorten")
def summarize(text, ctx):
    """Extractive summary of pasted text."""
    body = re.sub(r"^.*?\b(summari[sz]e|summary|tldr|shorten)\b[:\s]*", "", text, flags=re.I)
    sents = re.split(r"(?<=[.!?])\s+", body.strip())
    if len(sents) < 3: return "Paste at least three sentences after 'summarize:'."
    freq = {}
    for w in _words(body): freq[w] = freq.get(w, 0) + 1
    rank = sorted(range(len(sents)), key=lambda i: -sum(freq.get(w, 0) for w in _words(sents[i])) / (len(sents[i].split()) + 1))
    return " ".join(sents[i] for i in sorted(rank[:max(1, len(sents) // 3)]))

# ---------- coding ----------
@tool("run code", "execute code", "run python", "execute python")
def run_code(text, ctx):
    """Execute a Python snippet locally and return its output. Use: 'run code: <python here>'."""
    # Runs with the same OS privileges as this server -- don't expose this agent to untrusted
    # users without adding your own sandboxing/auth first.
    body = re.sub(r"^.*?\b(run code|execute code|run python|execute python)\b[:\s]*", "", text, flags=re.I | re.S)
    if not body.strip(): return "Give me code to run, e.g. 'run code: print(2+2)'."
    fd, path = tempfile.mkstemp(suffix=".py")
    try:
        with os.fdopen(fd, "w") as f: f.write(body)
        r = subprocess.run([sys.executable, path], capture_output=True, text=True, timeout=10)
        out = (r.stdout + r.stderr).strip()
        return out[:4000] if out else "(ran with no output)"
    except subprocess.TimeoutExpired:
        return "Code timed out after 10 seconds."
    finally:
        os.remove(path)

# ---------- browsing ----------
@tool("browse", "fetch", "open url", "read page", "visit")
def browse(text, ctx):
    """Fetch a web page and return its readable text. Use: 'browse https://example.com'. Needs internet."""
    m = re.search(r"https?://\S+", text)
    if not m: return "Give me a URL, e.g. 'browse https://example.com'."
    try:
        req = urllib.request.Request(m.group(0), headers={"User-Agent": "BaseAgent/1.0"})
        html = urllib.request.urlopen(req, timeout=8).read().decode("utf-8", "ignore")
    except Exception as e:
        return f"Couldn't fetch that page: {e}"
    body = re.sub(r"<(script|style)[^>]*>.*?</\1>", " ", html, flags=re.S | re.I)
    body = re.sub(r"<[^>]+>", " ", body)
    body = re.sub(r"\s+", " ", body).strip()
    return body[:2000] + ("..." if len(body) > 2000 else "")

@tool("web search", "google", "search the web", "look up online")
def web_search(text, ctx):
    """Search the web. Needs internet and an extra package: pip install ddgs"""
    q = re.sub(r"^.*?\b(web search|google|search the web|look up online)\b[:\s]*", "", text, flags=re.I).strip()
    if not q: return "Give me something to search for."
    try:
        from ddgs import DDGS
    except ImportError:
        return "Web search needs an extra package: run 'pip install ddgs' and try again."
    try:
        with DDGS() as d:
            hits = list(d.text(q, max_results=5))
    except Exception as e:
        return f"Search failed (check your internet connection): {e}"
    if not hits: return "No results found."
    return "\n".join(f"- {h.get('title')}: {h.get('href')}" for h in hits)

# ---------- network (scoped: your own machine, and hosts you explicitly name) ----------
@tool("network info", "my ip", "network status", "am i online")
def network_info(text, ctx):
    """Show this machine's own hostname, local IP, and whether the internet is reachable."""
    if not ctx["config"].get("network_tools_enabled", True):
        return "Network tools are turned off (network_tools_enabled in config.json)."
    host = socket.gethostname()
    try:
        local_ip = socket.gethostbyname(host)
    except Exception:
        local_ip = "unknown"
    online = False
    try:
        socket.create_connection(("1.1.1.1", 53), timeout=3).close()
        online = True
    except Exception:
        pass
    return f"Hostname: {host}\nLocal IP: {local_ip}\nInternet reachable: {'yes' if online else 'no'}"

@tool("ping")
def ping(text, ctx):
    """Ping a host you name, e.g. 'ping example.com'. Diagnostic only."""
    if not ctx["config"].get("network_tools_enabled", True):
        return "Network tools are turned off (network_tools_enabled in config.json)."
    m = re.search(r"ping\s+([\w.\-]+)", text, re.I)
    if not m: return "Tell me a host to ping, e.g. 'ping example.com'."
    flag = "-n" if platform.system().lower().startswith("win") else "-c"
    try:
        r = subprocess.run(["ping", flag, "3", m.group(1)], capture_output=True, text=True, timeout=10)
        return (r.stdout or r.stderr).strip()[:1500] or "No response."
    except Exception as e:
        return f"Ping failed: {e}"

# ---------- automation ----------
@tool("remind me every", "every day", "every hour", "schedule this", "automate", "every", "remind")
def schedule_task(text, ctx):
    """Repeat a task automatically, e.g. 'every 30 minutes remind me to stretch'."""
    if not ctx.get("scheduler"):
        return "Automation is turned off (automation_enabled in config.json)."
    m = re.search(r"every\s+(\d+)\s*(second|minute|hour|day)s?\b(.*)", text, re.I)
    if not m: return "Say it like: 'every 30 minutes remind me to stretch'."
    n, unit, rest = int(m.group(1)), m.group(2).lower(), m.group(3).strip(" :,-")
    mult = {"second": 1, "minute": 60, "hour": 3600, "day": 86400}[unit]
    ctx["scheduler"].add(ctx["sid"], n * mult, rest or "reminder")
    return f"Okay -- I'll run \u201c{rest or 'reminder'}\u201d every {n} {unit}{'s' if n != 1 else ''}."

# ---------- self-description ----------
@tool("help", "skills", "tools", "capabilities", "can you do")
def capabilities(text, ctx):
    """List everything this assistant can do, and which brain is answering."""
    lines = [f"- {n}: {t['doc']}" for n, t in ctx["agent"].registry.items()]
    using_llm = ctx["agent"].current_brain() is ctx["agent"].ollama
    mode = "a local language model via Ollama" if using_llm else "offline rule-based mode (no Ollama detected)"
    return f"Running in {mode}. I can:\n" + "\n".join(lines)
