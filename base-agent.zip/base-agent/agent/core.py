"""Agent core: loads config + skills, logs history, picks a brain, runs tools, persists memory.
Fully local. No API keys. Internet is only ever used by the specific tools that need it
(browse, web search) -- never required for the agent to run."""
import json, os, re
from .tools import REGISTRY
from .brains import RuleBrain, OllamaBrain
from .memory import Memory
from .automation import Scheduler

ROOT = os.path.join(os.path.dirname(__file__), "..")
SKILLS = os.path.join(ROOT, "skills")
CONFIG_PATH = os.path.join(ROOT, "config.json")

DEFAULT_CONFIG = {
    "brain": "auto",                        # "auto" | "ollama" | "rule"
    "ollama_url": "http://localhost:11434",
    "ollama_model": "llama3.1",
    "history_turns": 12,
    "network_tools_enabled": True,
    "automation_enabled": True,
}

def load_config():
    cfg = dict(DEFAULT_CONFIG)
    if os.path.exists(CONFIG_PATH):
        try:
            cfg.update(json.load(open(CONFIG_PATH, encoding="utf-8")))
        except Exception:
            pass
    return cfg

def load_skills(registry):
    """A skill is a folder: SKILL.md (name, description, triggers) + optional run.py with run(text, ctx)."""
    if not os.path.isdir(SKILLS): return
    for d in sorted(os.listdir(SKILLS)):
        md = os.path.join(SKILLS, d, "SKILL.md")
        if not os.path.exists(md): continue
        raw = open(md, encoding="utf-8").read()
        m = re.match(r"---\n(.*?)\n---\n?(.*)", raw, re.S)
        meta = dict(l.split(":", 1) for l in m.group(1).splitlines() if ":" in l) if m else {}
        body = m.group(2).strip() if m else raw
        name = meta.get("name", d).strip()
        trig = [x.strip().lower() for x in meta.get("triggers", "").split(",") if x.strip()]
        fn, run_path = None, os.path.join(SKILLS, d, "run.py")
        if os.path.exists(run_path):
            ns = {}; exec(compile(open(run_path, encoding="utf-8").read(), run_path, "exec"), ns); fn = ns.get("run")
        registry["skill_" + name.replace("-", "_")] = {
            "fn": fn or (lambda text, ctx, b=body: b), "keywords": trig, "doc": meta.get("description", "").strip()}

class Agent:
    def __init__(self):
        self.config = load_config()
        self.registry = dict(REGISTRY)
        load_skills(self.registry)
        self.mem = Memory()
        self.rules = RuleBrain()
        self.ollama = OllamaBrain(self.config["ollama_url"], self.config["ollama_model"], self.rules)
        self.scheduler = Scheduler(self) if self.config.get("automation_enabled", True) else None

    def current_brain(self):
        mode = self.config.get("brain", "auto")
        if mode == "rule": return self.rules
        if mode == "ollama": return self.ollama
        return self.ollama if self.ollama.available() else self.rules

    def run(self, sid, text):
        sid = re.sub(r"[^\w-]", "", sid)[:40] or "anon"
        text = text[:4000]
        ctx = {"mem": self.mem, "sid": sid, "agent": self, "scheduler": self.scheduler, "config": self.config}
        history = self.mem.recent(sid, self.config.get("history_turns", 12) * 2)
        self.mem.log(sid, "user", text)
        brain = self.current_brain()
        reply, trace = brain.respond(text, ctx, self.registry, history)
        self.mem.log(sid, "assistant", reply)
        return {"reply": reply, "trace": trace, "brain_mode": "ollama" if brain is self.ollama else "rule"}
