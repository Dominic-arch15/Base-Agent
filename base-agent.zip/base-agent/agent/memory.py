"""Local, persistent, per-user memory (SQLite, stdlib only).
A brand-new user id starts with nothing stored -- no facts, no history are
pre-loaded about anyone. Everything here is written only by this program, locally."""
import json, os, sqlite3, threading, time

DB_PATH = os.path.join(os.path.dirname(__file__), "..", "data", "memory.db")

class Memory:
    def __init__(self, path=DB_PATH):
        os.makedirs(os.path.dirname(path), exist_ok=True)
        self._lock = threading.Lock()
        self.conn = sqlite3.connect(path, check_same_thread=False)
        with self._lock:
            self.conn.execute("CREATE TABLE IF NOT EXISTS kv(user TEXT, key TEXT, value TEXT, ts REAL, PRIMARY KEY(user,key))")
            self.conn.execute("CREATE TABLE IF NOT EXISTS history(user TEXT, role TEXT, text TEXT, ts REAL)")
            self.conn.commit()

    # structured memory: notes, todos, preferences, anything JSON-serializable
    def get(self, user, key, default=None):
        with self._lock:
            r = self.conn.execute("SELECT value FROM kv WHERE user=? AND key=?", (user, key)).fetchone()
        return json.loads(r[0]) if r else default

    def set(self, user, key, value):
        with self._lock:
            self.conn.execute("INSERT OR REPLACE INTO kv VALUES (?,?,?,?)", (user, key, json.dumps(value), time.time()))
            self.conn.commit()

    def forget(self, user, key):
        with self._lock:
            self.conn.execute("DELETE FROM kv WHERE user=? AND key=?", (user, key))
            self.conn.commit()

    def all_facts(self, user):
        with self._lock:
            rows = self.conn.execute("SELECT key, value FROM kv WHERE user=?", (user,)).fetchall()
        return {k: json.loads(v) for k, v in rows}

    # conversation history: gives the LLM brain context across turns
    def log(self, user, role, text):
        with self._lock:
            self.conn.execute("INSERT INTO history VALUES (?,?,?,?)", (user, role, text, time.time()))
            self.conn.commit()

    def recent(self, user, n=24):
        with self._lock:
            rows = self.conn.execute(
                "SELECT role, text FROM history WHERE user=? ORDER BY ts DESC LIMIT ?", (user, n)).fetchall()
        return [{"role": r, "content": t} for r, t in reversed(rows)]

    def clear_history(self, user):
        with self._lock:
            self.conn.execute("DELETE FROM history WHERE user=?", (user,))
            self.conn.commit()
