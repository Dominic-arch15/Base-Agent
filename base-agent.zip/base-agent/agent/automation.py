"""Minimal local task scheduler. Jobs re-run an agent request on a timer and survive
restarts via data/jobs.json. Deliberately simple: it triggers the agent's own tools
(reminders, notes, skills, etc.) on a schedule -- it does not grant any access beyond
what the agent's tools already have."""
import json, os, threading, time

JOBS_PATH = os.path.join(os.path.dirname(__file__), "..", "data", "jobs.json")

class Scheduler:
    def __init__(self, agent):
        self.agent = agent
        self._lock = threading.Lock()
        os.makedirs(os.path.dirname(JOBS_PATH), exist_ok=True)
        self.jobs = json.load(open(JOBS_PATH)) if os.path.exists(JOBS_PATH) else []
        threading.Thread(target=self._loop, daemon=True).start()

    def _save(self):
        tmp = JOBS_PATH + ".tmp"
        json.dump(self.jobs, open(tmp, "w"), indent=1)
        os.replace(tmp, JOBS_PATH)

    def add(self, user, every_seconds, message):
        with self._lock:
            self.jobs.append({"user": user, "every": every_seconds, "message": message, "next": time.time() + every_seconds})
            self._save()

    def list_for(self, user):
        with self._lock:
            return [j for j in self.jobs if j["user"] == user]

    def _loop(self):
        while True:
            now = time.time()
            with self._lock:
                due = [j for j in self.jobs if now >= j["next"]]
            for j in due:
                try:
                    self.agent.run(j["user"], j["message"])
                except Exception:
                    pass
                j["next"] = now + j["every"]
            if due:
                with self._lock:
                    self._save()
            time.sleep(5)
