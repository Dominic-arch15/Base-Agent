# Base Agent

A from-scratch agentic AI assistant: it **plans** a request into steps, **reasons**, **chooses tools**, **acts**, **remembers**, and replies. The core runs on the Python standard library alone — no API keys, no cloud account, no required dependencies. Optional pieces (open-ended reasoning, web search, desktop voice) connect to things that also run on your own machine or need no key.

## Quick start
    python server.py          # then open http://localhost:8000
    docker build -t base-agent . && docker run -p 8000:8000 base-agent

Set the `PORT` / `HOST` environment variables to change the address. To put it on the public web, run it on a server (or a host like Render/Railway/Fly.io/a VPS) with a reverse proxy (nginx/Caddy) in front for HTTPS. It has no login or rate limiting, so anyone with the link can use it — add auth before exposing it beyond yourself.

## Everything is controlled from `config.json`, in the root folder
```json
{
  "brain": "auto",
  "ollama_url": "http://localhost:11434",
  "ollama_model": "llama3.1",
  "history_turns": 12,
  "network_tools_enabled": true,
  "automation_enabled": true
}
```
`"brain"`: `"auto"` uses a local model if one is running, otherwise falls back to the offline rule-based mode; `"ollama"` forces the model (and falls back automatically if it's unreachable); `"rule"` always stays offline. Turn `network_tools_enabled` / `automation_enabled` off to disable those tool groups entirely.

## Real reasoning, coding and problem-solving (optional, still no API key)
The built-in `RuleBrain` only routes keywords to tools — it cannot hold a conversation or write code on its own, no matter how it's extended. For actual reasoning you connect a real language model that runs **on your machine**, via [Ollama](https://ollama.com):

1. Install Ollama and run `ollama pull llama3.1` (or any model you prefer — a coding-focused one like `qwen2.5-coder` works well for programming tasks).
2. Leave Ollama running (`ollama serve`, or it runs automatically after install on most platforms).
3. Start `python server.py`. It detects Ollama automatically (`"brain": "auto"`) and the header in the web UI will say "local model connected."

With this connected, the agent can reason, write and explain code, and still call its own tools (calculator, notes, browsing, etc.) when it decides a tool is the right way to answer — it asks for one with a `TOOL: name: input` line, which `agent/brains.py` intercepts and executes. No internet or API key is needed once the model is pulled; Ollama and the agent talk over `localhost` only.

Without Ollama running, the agent still works — it just falls back to the offline rule-based mode, same as the tool-only version.

## Memory
Memory lives in `data/memory.db` (SQLite) and is created fresh — **a new user id starts with nothing stored**: no facts, no history, no profile. As you use it, it saves notes, tasks and conversation history locally, and nowhere else. It's used two ways: directly (the `note`/`task` tools), and as context handed to the local model so multi-turn conversations stay coherent. Delete `data/memory.db` any time to wipe everything.

## Tools
| Tool | What it does |
|---|---|
| `calculator` | Arithmetic |
| `clock` | Date/time |
| `notes` / `todos` | Persistent per-user notes and tasks |
| `search_knowledge` | Answers from the `knowledge/` folder |
| `summarize` | Extractive summary of pasted text |
| `run_code` | Runs a Python snippet locally and returns the output |
| `browse` | Fetches a URL and returns its readable text (needs internet) |
| `web_search` | Web search via `pip install ddgs` (needs internet, no API key) |
| `network_info` / `ping` | Diagnostics for **your own machine** and hosts you name |
| `schedule_task` | Runs a request on a repeating timer (`automation.py`) |
| skills in `skills/` | Drop-in extras, same `SKILL.md` format as above |

**Two tools are scoped deliberately, for safety and to match what a personal local tool should do:**
- `run_code` executes with the same OS privileges as the server process — that's what makes it useful on your own machine, and also why you shouldn't expose this agent to people you don't trust without adding your own sandboxing and authentication first.
- The network tools are diagnostics only (your own machine's status, and pinging a host you explicitly name). There's no device scanning or enumeration of other people's networks built in — if you need something more specific, add it as a tool in `agent/tools.py` with the same care.

## Automation
Say things like `every 30 minutes remind me to stretch` or `every 1 hour check tasks`. Jobs run in a background thread and are saved to `data/jobs.json`, so they survive a restart. A job just re-runs an agent request on a timer — it doesn't grant any access beyond what the tools above already have.

## Voice control
The web UI has voice control built in, using the browser's own microphone and speaker (the Web Speech API) — tap the mic button to talk, and turn on "speak replies" to hear answers. This needs no extra install and works in Chrome/Edge today; note that browsers typically do their speech-to-text by sending the audio to the browser maker's own servers (that's a browser/OS feature, not something this code controls).

If you'd rather have a standalone, non-browser voice assistant, `agent/voice.py` is an optional desktop loop:
```
pip install pyttsx3 SpeechRecognition pyaudio
python -m agent.voice
```
`pyttsx3` speaks fully offline. The default speech-to-text step uses the free, keyless Google Web Speech API (needs internet); swap it for a local engine like [Vosk](https://alphacephei.com/vosk/) in `agent/voice.py` if you want voice input to stay fully offline too. PyAudio (needed for microphone access) is a C extension and can be the fiddliest part to install on Windows — prebuilt wheels are usually the easiest route if `pip install pyaudio` fails.

## Layout
```
server.py            web server: /api/chat, /api/tools, /api/config, /api/health
config.json           root-folder customization (read by agent/core.py)
agent/core.py          agent loop: config, skills, memory, brain selection
agent/brains.py         RuleBrain (offline) and OllamaBrain (local model)
agent/tools.py           built-in tools
agent/memory.py           persistent per-user memory (SQLite)
agent/automation.py        background job scheduler
agent/voice.py              optional desktop voice loop
skills/<name>/SKILL.md       drop-in abilities (+ optional run.py)
knowledge/                    documents the agent can answer from
web/index.html                  chat + voice UI
```

## Upgrade it further
1. **Tools**: add `@tool("keyword", ...)` functions in `agent/tools.py`.
2. **Skills**: add a folder under `skills/` and restart.
3. **Knowledge**: drop `.md`/`.txt` files in `knowledge/`.
4. **A different/bigger local model**: change `ollama_model` in `config.json` to anything you've pulled.
5. **A smarter brain entirely**: `agent/brains.py` just needs a class with `respond(text, ctx, registry, history) -> (reply, trace)` — point `Agent.ollama` (or add a third option) at whatever you build.

## Honest limits
- Without Ollama connected, reasoning is keyword-based and will say so plainly rather than guess.
- `run_code` and the network tools are real capabilities on real infrastructure — treat this like any other local dev tool: fine for yourself, not something to hand out publicly without adding your own access control.
- This project ships with no content moderation layer of its own; if you connect a model via Ollama, its behavior is whatever that model does. That's a deliberate choice to keep the base program small and honest about what it is, not a guarantee about what any model you plug in will or won't do — that responsibility is yours as the operator, the same as running any other local AI tool.
